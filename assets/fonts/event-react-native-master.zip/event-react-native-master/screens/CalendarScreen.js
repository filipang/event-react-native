import React from 'react';
import CalendarPicker from '../components/CalendarPicker';
const CalendarScreen = () => {
    return <CalendarPicker/>
}

export default CalendarScreen;
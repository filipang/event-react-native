import React, { memo } from "react";
import { StyleSheet, Text } from "react-native";

const MainScreen = () =>{
    return <Text>mama </Text>
};

const styles = StyleSheet.create({

})

export default memo(MainScreen);
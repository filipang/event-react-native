import React, { memo } from "react";
import TagChooser from './TagChooser';


export default class Dashboard extends React.Component {


    render() {
        return (<TagChooser/>)
    }
}




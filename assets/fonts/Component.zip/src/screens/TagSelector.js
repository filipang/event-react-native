import React, { Component } from "react";
import { StyleSheet, View, Text } from "react-native";
import MaterialSearchBar from "../components/MaterialSearchBar";
import MaterialChipWithCloseButton from "../components/MaterialChipWithCloseButton";
import MaterialChipWithCloseButton1 from "../components/MaterialChipWithCloseButton1";
import MaterialChipBasic from "../components/MaterialChipBasic";
import MaterialChipBasic1 from "../components/MaterialChipBasic1";
import MaterialChipBasic2 from "../components/MaterialChipBasic2";
import MaterialChipBasic3 from "../components/MaterialChipBasic3";
import MaterialButtonViolet2 from "../components/MaterialButtonViolet2";
import MaterialIconTextButtonsFooter from "../components/MaterialIconTextButtonsFooter";

function TagSelector(props) {
  return (
    <View style={styles.container}>
      <MaterialSearchBar style={styles.materialSearchBar}></MaterialSearchBar>
      <View style={styles.materialChipWithCloseButtonRow}>
        <MaterialChipWithCloseButton
          style={styles.materialChipWithCloseButton}
        ></MaterialChipWithCloseButton>
        <MaterialChipWithCloseButton1
          style={styles.materialChipWithCloseButton1}
        ></MaterialChipWithCloseButton1>
      </View>
      <View style={styles.materialChipBasicRow}>
        <MaterialChipBasic style={styles.materialChipBasic}></MaterialChipBasic>
        <MaterialChipBasic1
          style={styles.materialChipBasic2}
        ></MaterialChipBasic1>
        <MaterialChipBasic2
          style={styles.materialChipBasic22}
        ></MaterialChipBasic2>
      </View>
      <Text style={styles.selectedTags}>Selected Tags:</Text>
      <Text style={styles.allTags}>All Tags:</Text>
      <View style={styles.materialChipBasic26Row}>
        <MaterialChipBasic3
          style={styles.materialChipBasic26}
        ></MaterialChipBasic3>
        <MaterialChipBasic3
          style={styles.materialChipBasic3}
        ></MaterialChipBasic3>
        <MaterialChipBasic3
          style={styles.materialChipBasic23}
        ></MaterialChipBasic3>
      </View>
      <View style={styles.materialChipBasic25Row}>
        <MaterialChipBasic3
          style={styles.materialChipBasic25}
        ></MaterialChipBasic3>
        <MaterialChipBasic3
          style={styles.materialChipBasic24}
        ></MaterialChipBasic3>
      </View>
      <MaterialButtonViolet2
        style={styles.materialButtonViolet2}
      ></MaterialButtonViolet2>
      <MaterialIconTextButtonsFooter
        style={styles.materialIconTextButtonsFooter}
      ></MaterialIconTextButtonsFooter>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  materialSearchBar: {
    width: 360,
    height: 62
  },
  materialChipWithCloseButton: {
    width: 112,
    height: 32
  },
  materialChipWithCloseButton1: {
    width: 115,
    height: 32,
    marginLeft: 14
  },
  materialChipWithCloseButtonRow: {
    height: 32,
    flexDirection: "row",
    marginTop: 51,
    marginLeft: 16,
    marginRight: 103
  },
  materialChipBasic: {
    width: 84,
    height: 32
  },
  materialChipBasic2: {
    width: 84,
    height: 32,
    marginLeft: 4
  },
  materialChipBasic22: {
    width: 84,
    height: 32,
    marginLeft: 6
  },
  materialChipBasicRow: {
    height: 32,
    flexDirection: "row",
    marginTop: 64,
    marginLeft: 30,
    marginRight: 68
  },
  selectedTags: {
    width: 207,
    height: 20,
    color: "#121212",
    fontFamily: "roboto-regular",
    marginTop: -159,
    marginLeft: 30
  },
  allTags: {
    width: 207,
    height: 20,
    color: "#121212",
    fontFamily: "roboto-regular",
    marginTop: 69,
    marginLeft: 21
  },
  materialChipBasic26: {
    width: 84,
    height: 32
  },
  materialChipBasic3: {
    width: 84,
    height: 32,
    marginLeft: 4
  },
  materialChipBasic23: {
    width: 84,
    height: 32,
    marginLeft: 6
  },
  materialChipBasic26Row: {
    height: 32,
    flexDirection: "row",
    marginTop: 58,
    marginLeft: 30,
    marginRight: 68
  },
  materialChipBasic25: {
    width: 84,
    height: 32
  },
  materialChipBasic24: {
    width: 84,
    height: 32,
    marginLeft: 4
  },
  materialChipBasic25Row: {
    height: 32,
    flexDirection: "row",
    marginTop: 7,
    marginLeft: 30,
    marginRight: 158
  },
  materialButtonViolet2: {
    width: 100,
    height: 36,
    borderColor: "#000000",
    borderWidth: 0,
    marginTop: 140,
    alignSelf: "center"
  },
  materialIconTextButtonsFooter: {
    width: 362,
    height: 56,
    marginTop: 87,
    marginLeft: 408
  }
});

export default TagSelector;
